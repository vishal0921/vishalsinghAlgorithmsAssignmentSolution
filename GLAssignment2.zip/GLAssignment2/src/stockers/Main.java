package stockers;

import java.util.Scanner;

public class Main {
	static int noofcompanies = 0;
	static int choice;
	static double share_price[];
	static boolean share_value[];
	static int presstoexit;
	static double key;
	static int nooftimespricerose;
	static int nooftimespricedeclined;

	public static void main(String args[]) {

		MergeSort mergesort = new MergeSort();

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the no of companies");
		noofcompanies = sc.nextInt();
		share_price = new double[noofcompanies];
		share_value = new boolean[noofcompanies];
		for (int i = 0; i < noofcompanies; i++) {
			System.out.println("Enter current stock price of the company " + (i + 1));
			share_price[i] = sc.nextDouble();
			System.out.println("Whether company's stock price rose today compare to yesterday?");
			share_value[i] = sc.nextBoolean();
		}

		while (noofcompanies > 0) {
			System.out.println("Enter the operation that you want to perform\r\n"
					+ "1. Display the companies stock prices in ascending order\r\n"
					+ "2. Display the companies stock prices in descending order\r\n"
					+ "3. Display the total no of companies for which stock prices rose today\r\n"
					+ "4. Display the total no of companies for which stock prices declined today\r\n"
					+ "5. Search a specific stock price\r\n" + "6. press 0 to exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				mergesort.sortArray(share_price, 0, share_price.length - 1);
				System.out.println("Stock prices in ascending order are");
				mergesort.printValuesascending(share_price);
				continue;
			case 2:
				mergesort.sortArray(share_price, 0, share_price.length - 1);
				System.out.println("Stock prices in descending order are");
				mergesort.printValuesdescending(share_price);
				continue;
			case 3:
				nooftimespricerose = searchstockpricerise(share_value, key);
				System.out.println("total no of companies for which stock prices rose today:" + nooftimespricerose);
				continue;
			case 4:
				nooftimespricedeclined = searchstockpricedecline(share_value, key);
				System.out.println(
						"total no of companies for which stock prices declined today:" + nooftimespricedeclined);
				continue;
			case 5:
				System.out.println("enter the key value");
				key = sc.nextDouble();
				searchstockprice(share_price, key);
				continue;
			case 6:
				presstoexit = sc.nextInt();

			}
			if (presstoexit == 0) {
				break;
			}
		}

		sc.close();
	}

	public static void searchstockprice(double share_price[], double key) {
		int flag = 0;
		for (int i = 0; i < share_price.length; i++) {
			if (key == share_price[i]) {
				flag++;
				break;
			} else {
				continue;
			}
		}
		if (flag > 0) {
			System.out.println("Stock of value " + key + " is present");
		} else {
			System.out.println("Stock of value " + key + " is not present");
		}

	}

	public static int searchstockpricerise(boolean share_value[], double key) {
		int counttrue = 0;
		for (int i = 0; i < share_value.length; i++) {
			if (share_value[i] == true) {
				counttrue++;
			}
		}
		return counttrue;
	}

	public static int searchstockpricedecline(boolean share_value[], double key) {
		int countfalse = 0;
		for (int i = 0; i < share_value.length; i++) {
			if (share_value[i] == false) {
				countfalse++;
			}
		}
		return countfalse;

	}

}
