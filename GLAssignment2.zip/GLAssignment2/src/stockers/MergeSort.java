package stockers;

public class MergeSort {

	public int i, NUM_ELEMENTS;

	public void sortArray(double[] share_price, int l, int r) {
		if (l < r) {
			int m = l + (r - l) / 2;
			sortArray(share_price, l, m);
			sortArray(share_price, m + 1, r);
			conquerArray(share_price, l, m, r);
		}
	}

	public void conquerArray(double[] share_price, int l, int m, int r) {
		int n1 = m - l + 1;
		int n2 = r - m;
		double L[] = new double[n1];
		double R[] = new double[n2];
		for (i = 0; i < n1; ++i) {
			L[i] = share_price[l + i];
		}
		for (int j = 0; j < n2; ++j) {
			R[j] = share_price[m + 1 + j];
		}
		int i = 0, j = 0;
		int k = l;
		while (i < n1 && j < n2) {
			if (L[i] <= R[j]) {
				share_price[k] = L[i];
				i++;
			} else {
				share_price[k] = R[j];
				j++;
			}
			k++;
		}
		while (i < n1) {
			share_price[k] = L[i];
			i++;
			k++;
		}
		while (j < n2) {
			share_price[k] = R[j];
			j++;
			k++;
		}

	}

	public void printValuesascending(double share_price[]) {
		for (int i = 0; i < share_price.length; i++) {
			System.out.println(" " + share_price[i]);
		}
	}

	public void printValuesdescending(double share_price[]) {
		for (int i = share_price.length; i > 0; i--) {
			System.out.println(" " + share_price[i - 1]);
		}
	}
}
